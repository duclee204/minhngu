package com.example.hrms.biz.request.controller;


import ch.qos.logback.core.model.Model;

import com.example.hrms.biz.booking.model.Booking;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/api/V1/requests")
public class RequestController {

    @RequestMapping("")
    public String openRequestView(Model model) {
        return "requests";
    }
}
